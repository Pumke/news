# 搭建

## 环境

需要 Node.js v7.6.0 或更高版本，若启用 Redis 缓存需要先启动 Redis

## 安装

安装依赖：`yarn`

修改配置：配置文件为 `config.js`

启动程序：`node index.js`
