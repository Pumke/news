const axios = require('axios');
const template = require('../../utils/template');
const config = require('../../config');

module.exports = async (ctx) => {
    const company = ctx.params.company;
    const number = ctx.params.number;

    const response = await axios({
        method: 'get',
        url: `https://www.kuaidi100.com/query?type=${company}&postid=${number}`,
        headers: {
            'User-Agent': config.ua,
            'Referer': 'https://www.kuaidi100.com'
        }
    });

    const data = response.data.data;

    ctx.body = template({
        title: `快递 ${company}-${number}`,
        link: 'https://www.kuaidi100.com',
        description: `快递 ${company}-${number}`,
        item: data.map((item) => ({
            title: item.context,
            description: item.context,
            pubDate: new Date(item.time || item.ftime).toUTCString(),
            link: item.context
        })),
    });
};